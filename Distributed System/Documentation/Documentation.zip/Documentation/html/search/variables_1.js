var searchData=
[
  ['fil',['fil',['../namespaceclient.html#a80405e0bc3f510b7ccc5e6393379fced',1,'client.fil()'],['../namespaceserver.html#a317d711bd08dccc668c4de18fac47325',1,'server.fil()']]]
];
