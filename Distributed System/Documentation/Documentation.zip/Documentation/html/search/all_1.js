var searchData=
[
  ['client',['client',['../namespaceclient.html',1,'']]],
  ['client_2epy',['client.py',['../client_8py.html',1,'']]]
];
