var searchData=
[
  ['get_5fcompile_5fresult',['get_compile_result',['../namespaceserver.html#a3443add8fb006cd82bb019b183abb3e7',1,'server']]],
  ['get_5fprogram',['get_program',['../namespaceclient.html#a1d26e7882f5ffbaebf5df1f1dbf9bec7',1,'client']]],
  ['get_5fprogram_5fraport',['get_program_raport',['../namespaceserver.html#aa88e2a04c40afb12a1d86b09232d2ace',1,'server']]],
  ['get_5fprogram_5fresult',['get_program_result',['../namespaceserver.html#a6e085450c11ebb90bdf9d64289f5b091',1,'server']]]
];
