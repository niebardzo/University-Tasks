var searchData=
[
  ['wybor',['wybor',['../namespaceclient.html#aaa3805e0a8fe8758967e6b1466d17c2b',1,'client.wybor()'],['../namespaceserver.html#a5e132097fe5babc02bbb87908f76c974',1,'server.wybor()']]]
];
