var searchData=
[
  ['server',['server',['../namespaceserver.html',1,'']]]
];
