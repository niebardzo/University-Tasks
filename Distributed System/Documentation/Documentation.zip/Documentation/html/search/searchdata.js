var indexSectionsWithContent =
{
  0: "acfgiprstw",
  1: "cps",
  2: "cps",
  3: "grs",
  4: "afiptw"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Przestrzenie nazw",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

