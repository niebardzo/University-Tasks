var searchData=
[
  ['client',['client',['../namespaceclient.html',1,'']]]
];
