var searchData=
[
  ['port',['port',['../namespaceclient.html#aef595fb9fb915606023d8f82f151ff96',1,'client.port()'],['../namespaceserver.html#a042206a6014ef1fa86079665a1a39226',1,'server.port()']]],
  ['port2',['port2',['../namespaceclient.html#a56a81835a74471cf4e3f38d4f4681933',1,'client.port2()'],['../namespaceserver.html#abdcd32f44a65f3a722f7e8b3c5def604',1,'server.port2()']]]
];
