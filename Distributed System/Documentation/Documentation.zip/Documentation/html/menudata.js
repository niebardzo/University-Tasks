var menudata={children:[
{text:"Strona główna",url:"index.html"},
{text:"Pakiety",url:"namespaces.html",children:[
{text:"Pakiety",url:"namespaces.html"},
{text:"Funkcje pakietu",url:"namespacemembers.html",children:[
{text:"Wszystko",url:"namespacemembers.html"},
{text:"Funkcje",url:"namespacemembers_func.html"},
{text:"Zmienne",url:"namespacemembers_vars.html"}]}]},
{text:"Pliki",url:"files.html",children:[
{text:"Lista plików",url:"files.html"}]}]}
